package com.example.examaistudio

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.browser.customtabs.CustomTabsIntent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF090D18)
private val Panel = Color(0xFF151B2D)
private val Muted = Color(0xFF9AA6C1)
private val Purple = Color(0xFF9B62FF)
private val Cyan = Color(0xFF39D8E8)
private val Green = Color(0xFF45E0A0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ExamAiApp() }
    }
}

@Composable
fun ExamAiApp() {
    var targetUrl by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("Siap untuk sesi belajar.") }
    var selected by remember { mutableStateOf("Dashboard") }
    val context = LocalContext.current

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Purple,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF10172B), Bg))
            ).verticalScroll(rememberScrollState()).padding(20.dp)
        ) {
            Text("EXAM AI STUDIO", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Text("Belajar lebih cerdas.", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
            Text("AI Study Companion  •  v1.0", color = Cyan, fontSize = 13.sp)
            Spacer(Modifier.height(22.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF351923)),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFFF5368), RoundedCornerShape(18.dp))
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("⚠  MODE BELAJAR", color = Color(0xFFFF7888), fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Gunakan untuk latihan, materi, dan formulir yang kamu miliki atau diizinkan untuk diuji. Aplikasi ini tidak melewati pengamanan ujian.",
                        color = Color(0xFFFFD7DD), fontSize = 13.sp, lineHeight = 19.sp
                    )
                }
            }
            Spacer(Modifier.height(18.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatusCard("AI STATUS", "READY", Green, Modifier.weight(1f))
                StatusCard("MODE", "PRACTICE", Cyan, Modifier.weight(1f))
            }
            Spacer(Modifier.height(22.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = Panel),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, Purple.copy(alpha = .8f), RoundedCornerShape(20.dp))
            ) {
                Column(Modifier.padding(18.dp)) {
                    Text("TARGET BELAJAR", color = Color(0xFFC59BFF), fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = targetUrl,
                        onValueChange = { targetUrl = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = { Text("https://alamat-form-latihan.com") },
                        label = { Text("URL materi / formulir latihan") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Purple, unfocusedBorderColor = Color(0xFF65518A),
                            focusedLabelColor = Purple, cursorColor = Purple
                        )
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val raw = targetUrl.trim()
                            val parsed = Uri.parse(raw)
                            if ((parsed.scheme == "https" || parsed.scheme == "http") && !parsed.host.isNullOrBlank()) {
                                try {
                                    CustomTabsIntent.Builder().setShowTitle(true).build()
                                        .launchUrl(context, parsed)
                                    notice = "Halaman latihan dibuka di browser aman."
                                } catch (_: Exception) {
                                    notice = "Tidak dapat membuka URL. Periksa alamat dan browser."
                                }
                            } else {
                                notice = "Masukkan URL lengkap yang diawali https:// atau http://"
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(54.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Purple),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("BUKA TARGET LATIHAN", fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(notice, color = Muted, fontSize = 12.sp)
                }
            }

            Spacer(Modifier.height(24.dp))
            Text("AI TOOLS", color = Color(0xFFC59BFF), fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.height(12.dp))

            ToolCard("Jawab Otomatis", "Bantu memahami soal latihan dengan penjelasan langkah demi langkah.", Icons.Default.AutoAwesome, Green) {
                selected = "Jawab Otomatis"
            }
            ToolCard("Prediksi Nilai", "Estimasi hasil dari kuis latihan yang sudah kamu kerjakan.", Icons.Default.Calculate, Color(0xFFFF5C9A)) {
                selected = "Prediksi Nilai"
            }
            ToolCard("Buka Chat AI", "Tanya konsep, minta contoh, atau bahas jawaban.", Icons.Default.ChatBubble, Cyan) {
                selected = "Buka Chat AI"
            }
            ToolCard("Atur Opositas", "Pengaturan tampilan dan preferensi asisten belajar.", Icons.Default.Tune, Color(0xFFFFD34E)) {
                selected = "Atur Opositas"
            }

            if (selected != "Dashboard") {
                Spacer(Modifier.height(12.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(selected, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 18.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            when (selected) {
                                "Jawab Otomatis" -> "Tempel soal latihan di Chat AI untuk mendapatkan pembahasan, bukan mengambil jawaban dari sesi ujian yang sedang berlangsung."
                                "Prediksi Nilai" -> "Masukkan jumlah jawaban benar dan total soal latihan untuk menghitung estimasi nilai."
                                "Buka Chat AI" -> "Integrasi model AI memerlukan backend dan API key yang disimpan aman di server."
                                else -> "Atur tema, ukuran teks, bahasa, dan preferensi tampilan aplikasi."
                            },
                            color = Muted, fontSize = 13.sp
                        )
                    }
                }
            }
            Spacer(Modifier.height(26.dp))
            Text("EXAM AI STUDIO  •  Built for learning", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun StatusCard(title: String, value: String, accent: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.border(1.dp, accent, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Muted, fontSize = 11.sp)
            Spacer(Modifier.height(7.dp))
            Text(value, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
        }
    }
}

@Composable
fun ToolCard(title: String, subtitle: String, icon: ImageVector, accent: Color, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
            .border(1.dp, accent.copy(alpha = .75f), RoundedCornerShape(17.dp))
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(17.dp)
    ) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(Modifier.height(3.dp))
                Text(subtitle, color = Muted, fontSize = 11.sp, lineHeight = 15.sp)
            }
        }
    }
}
