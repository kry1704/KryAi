# Exam AI Studio — Android starter

Starter project Android native dengan Kotlin + Jetpack Compose, tema gelap premium, kolom URL latihan, dan empat menu:
1. Jawab Otomatis
2. Prediksi Nilai
3. Buka Chat AI
4. Atur Opositas

## Membuka project
1. Ekstrak ZIP.
2. Buka folder `ExamAIStudio` melalui Android Studio.
3. Tunggu Gradle Sync.
4. Jalankan ke emulator atau HP Android dengan USB debugging.

## Catatan
- Tombol URL hanya membuka halaman HTTP/HTTPS di Chrome Custom Tabs; tidak melakukan injection, bypass, atau mengambil jawaban.
- Menu AI masih berupa kerangka antarmuka. Untuk AI sungguhan, tambahkan backend sendiri dan simpan API key di server, bukan di APK.
- Ubah `applicationId` dan `namespace` sebelum publikasi.
